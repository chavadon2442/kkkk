from setuptools import setup, find_packages

with open("README.md", "r") as fh:
    long_description = fh.read()

setup(
    name="Human-assisted-tagging",
    version="1.3",
    author="CVD",
    author_email="eiq.nattapon@gmail.com",
    description="Some description",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/adarsh2012/Human-assisted-tagging",
    license="MIT",
    packages=find_packages(),
    include_package_data=True,
    
    install_requires=[
        'numpy', 'pandas', 'sklearn'
    ],

    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Development Status :: 3 - Alpha"
    ])